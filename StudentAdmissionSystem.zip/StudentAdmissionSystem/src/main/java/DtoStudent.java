public record DtoStudent(
        String roll,
        String name,
        Integer age
) {
    public EntityStudent withId(int studentId) {
        return new EntityStudent(studentId, roll, name, age);
    }
}