public record EntityCourse(int id, String name, int duration) {
    @Override
    public String toString() {
        return "EntityCourse{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", duration=" + duration +
                '}';
    }
}