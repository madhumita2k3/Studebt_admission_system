public class Main {
    public static void main(String[] args) {
        try {
            AdmissionDao dao = new AdmissionDao();

            dao.insertStudent(new DtoStudent("1", "Shreya", 22));
            dao.insertStudent(new DtoStudent("2", "Madhumita", 22));
            dao.insertStudent(new DtoStudent("3", "Preeti", 22));
            dao.insertStudent(new DtoStudent("4", "Nabanita", 22));
            dao.insertStudent(new DtoStudent("5", "Payel", 22));

            dao.updateAgeById(1, 23);
            dao.deleteById(5);

            dao.insertCourse(new DtoCourse("MCA", 2));
            dao.insertCourse(new DtoCourse("ECE", 4));
            dao.insertCourse(new DtoCourse("BCA", 3));

            System.out.println("-------All Courses-------");
            dao.getAllCourses().forEach(System.out::println);
        } catch (Exception e) {
            System.out.println("Error Occurred: " + e.getMessage());
        }
    }
}
