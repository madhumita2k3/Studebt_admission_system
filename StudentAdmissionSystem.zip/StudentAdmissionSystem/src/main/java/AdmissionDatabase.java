import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AdmissionDatabase {
    private static final String SERVER_URL = "jdbc:mysql://localhost:3306/";
    private static final String URL = "jdbc:mysql://localhost:3306/admission";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "password";

    private static Connection connection;

    private static final String database = "CREATE DATABASE IF NOT EXISTS admission";
    private final static String student = "CREATE TABLE IF NOT EXISTS student (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "roll VARCHAR(20)," +
            "name VARCHAR(100)," +
            "age INT" +
            ")";
    private final static String course = "CREATE TABLE IF NOT EXISTS course (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "name VARCHAR(100)," +
            "duration INT" +
            ")";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(SERVER_URL, USERNAME, PASSWORD);
                 Statement st = con.createStatement();) {
                st.execute(database);
            }

            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            Statement st = connection.createStatement();
            st.executeUpdate(student);
            st.executeUpdate(course);

            System.out.println("Database connection established successfully!");
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Database initialization failed: " + e.getMessage());
            System.exit(1);
        }
    }

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed())
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        return connection;
    }

    public static void closeConnection() {
        if (connection != null) try {
            connection.close();
            System.out.println("Database connection closed.");
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}
