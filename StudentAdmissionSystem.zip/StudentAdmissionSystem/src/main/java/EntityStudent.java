public record EntityStudent(int id, String roll, String name, int age) {
    @Override
    public String toString() {
        return "DtoStudent{" +
                "id=" + id +
                ", roll='" + roll + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}