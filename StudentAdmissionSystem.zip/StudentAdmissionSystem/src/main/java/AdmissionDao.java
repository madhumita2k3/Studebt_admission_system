import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdmissionDao {
    private static final String insertStudent = "INSERT INTO student (roll, name, age) VALUES (?, ?, ?)";
    private static final String deleteStudent = "DELETE FROM student WHERE id = ?";
    private static final String updateStudentAgeById = "UPDATE student SET age = ? WHERE id = ?";

    private static final String insertCourse = "INSERT INTO course (name, duration) VALUES (?, ?)";
    private static final String allCourse = "SELECT * FROM course";

    public EntityStudent insertStudent(DtoStudent student) {
        try (Connection con = AdmissionDatabase.getConnection();
             PreparedStatement st = con.prepareStatement(insertStudent, Statement.RETURN_GENERATED_KEYS)
        ) {
            st.setString(1, student.roll());
            st.setString(2, student.name());
            st.setInt(3, student.age());

            int isDone = st.executeUpdate();
            if (isDone > 0) {
                try (ResultSet resultSet = st.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        int id = resultSet.getInt(1);
                        EntityStudent newStudent = student.withId(id);
                        System.out.println("Inserted: " + newStudent);

                        return newStudent;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Student Insertion Failed");
            System.out.println(e.getMessage());
        }

        return null;
    }

    public boolean deleteById(int id) {
        try (Connection con = AdmissionDatabase.getConnection();
             PreparedStatement st = con.prepareStatement(deleteStudent)) {
            st.setInt(1, id);

            int isDone = st.executeUpdate();
            if (isDone > 0) {
                System.out.println("Deleted Student with ID: " + id);
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Deleting Student Failed");
            System.out.println(e.getMessage());
        }

        return false;
    }

    public boolean updateAgeById(int id, int age) {
        try (Connection con = AdmissionDatabase.getConnection();
             PreparedStatement st = con.prepareStatement(updateStudentAgeById)) {
            st.setInt(1, age);
            st.setInt(2, id);

            int isDone = st.executeUpdate();
            if (isDone > 0) {
                System.out.println("Updated Student with ID: " + id);
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Update Student Failed");
            System.out.println(e.getMessage());
        }

        return false;
    }


    public EntityCourse insertCourse(DtoCourse course) {
        try (Connection con = AdmissionDatabase.getConnection();
             PreparedStatement st = con.prepareStatement(insertCourse, Statement.RETURN_GENERATED_KEYS)
        ) {
            st.setString(1, course.name());
            st.setInt(2, course.duration());

            int isDone = st.executeUpdate();
            if (isDone > 0) {
                try (ResultSet resultSet = st.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        int id = resultSet.getInt(1);
                        EntityCourse newCourse = course.withId(id);
                        System.out.println("Inserted: " + newCourse);

                        return newCourse;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Course Insertion Failed");
            System.out.println(e.getMessage());
        }

        return null;
    }

    public List<EntityCourse> getAllCourses() {
        List<EntityCourse> courseList = new ArrayList<>();

        try (Connection con = AdmissionDatabase.getConnection();
             PreparedStatement st = con.prepareStatement(allCourse);
             ResultSet rs = st.executeQuery(allCourse)) {
            while (rs.next()) {
                courseList.add(
                        new EntityCourse(
                                rs.getInt("id"),
                                rs.getString("name"),
                                rs.getInt("duration")
                        )
                );
            }
        } catch (SQLException e) {
            System.out.println("Getting All Course Failed");
            System.out.println(e.getMessage());
        }

        return courseList;
    }
}
