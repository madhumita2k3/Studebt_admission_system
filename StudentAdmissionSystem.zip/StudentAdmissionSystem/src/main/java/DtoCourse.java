public record DtoCourse(
        String name,
        int duration
) {
    public EntityCourse withId(int courseId) {
        return new EntityCourse(courseId, name, duration);
    }
}